def foo():
    x = 10
    print(x)
    
foo()
print(x)
