class Likelion:
    def __init__(self, name, schoolnum, grade):
        self.name = name
        self.schoolnum = schoolnum
        self.grade = grade
    
    def print_name(self):
        print(f'이름은 {self.name} 입니다')
    
    def print_schoolnum(self):
        print(f'학번은 {self.schoolnum} 입니다')
    
    def print_grade(self):
        print(f'학년은 {self.grade} 입니다')

youngbeen = Likelion('주영빈', 202114041, 3)
likelion = Likelion('likelion', 1234, 1)

youngbeen.print_name()
youngbeen.print_schoolnum()
youngbeen.print_grade()

likelion.print_name()
likelion.print_schoolnum()
likelion.print_grade()