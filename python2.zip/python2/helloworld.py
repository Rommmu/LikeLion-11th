string = "202114041"

print(string[5:6])