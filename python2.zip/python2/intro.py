def intro(name, schoolNum, grade):
    print(f'이름은 {name}\n학번은 {schoolNum}\n학년은 {grade}')

intro(**{'name': '주영빈', 'schoolNum': 202114041, 'grade': 3})