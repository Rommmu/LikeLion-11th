def cal(a, b):
    return a + b, a - b, a * b, a / b

add, sub, mul, div = cal(6, 3)
print(f'합은 {add} 차는 {sub} 곱은 {mul} 몫은 {div}')