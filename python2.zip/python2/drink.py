def drink(age):
    if (age < 20):
        return
    print(age, "살로 음주가 가능합니다.")

drink(18)
print()
drink(19)